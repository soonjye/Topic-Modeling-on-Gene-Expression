TCGA-BreastCancer
- contains 229 sample (112 normal, 117 cancer)
- 1st column: Ensembl_ID for gene
- 2nd-113th column: Normal tissue sample
- 114th-230th column: Cancer tissue sample



TCGA-LungCancer
- contains 98 sample (49 normal, 49 cancer)
- 1st column: Ensembl_ID for gene
- 2nd-50th column: Normal tissue sample
- 51th-99th column: Cancer tissue sample



For the use of data, please properly acknowledge TCGA in publications and presentations.
https://cancergenome.nih.gov/publications/publicationguidelines